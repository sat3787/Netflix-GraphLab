import os
import graphlab
import sys
import subprocess
os.chdir('/home/satish/download/training_set')
if os.path.exists('training_frame'):
	input=graphlab.SFrame('training_frame')
else:
	print('The input data doesnot exist')

#Check the input data
print('The head of Netflix data is as below:\n')
input.print_rows(num_rows=20,num_columns=4)
if (input.num_rows()==0) or (input.num_columns()==0):
	print('The input data SFrame is corrupted')
# Train the Model for makin predictions
Model_FR=graphlab.factorization_recommender.create(input,user_id='User',item_id='Movie',target='Rating',max_iterations=100)
Model_FR.save('my_FR_model')
