# Importing the packages required for the program
import os
import sys
import graphlab

def main():
	os.chdir("/home/satish/download/training_set")       
	main_data=graphlab.SFrame('netflix_training_sframe')
	train,test=graphlab.recommender.util.random_split_by_user(main_data,user_id='User',item_id='Movie')
	train.save('training_frame')
	test.save('testing_frame')

main()

	





