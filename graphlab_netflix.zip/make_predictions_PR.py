import os
import graphlab
import subprocess
import sys
os.chdir('/home/satish/download/training_set/')

#load the trained model
loaded_model=graphlab.load_model('my_PR_model')

#load the test data set
test_set=graphlab.SFrame('testing_frame')
actual_ratings=test_set.select_column('Rating')

#predict the ratings on test data set
predicted_ratings=loaded_model.predict(test_set)
predicted_ratings.save('predictions_PR')

#Calculate RMSE for predictions
if (actual_ratings.size()!=predicted_ratings.size()):
	print("There exists a mismatch in number of predictions and actuals")
else:
	rmse_val=graphlab.evaluation.rmse(actual_ratings,predicted_ratings)
	print("RMSE=\n")
	print(rmse_val)

#Make recommendations for each user
recommended=loaded_model.recommend(users=test_set.select_column('User'),k=3)
recommended.save('recommended_PR')

#Calculate precision and recall scores for the test dataset
prec_scores=loaded_model.evaluate_precision_recall(test_set)
print(prec_scores)

#print the summary for the model
print(loaded_model.summary())

