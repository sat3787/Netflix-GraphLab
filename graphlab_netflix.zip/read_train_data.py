# Importing the packages required for the program
import os
import sys
import graphlab
import subprocess

# Fetch the list of files in the given directory or sub-directories
def Get_ListofFiles():
# Execute a find command to list all the files in the directory
        file_string=subprocess.check_output("ls")
# Parse through the list of files and replace the escape sequence characters
        if len(file_string)!=0:
                file_string=file_string.replace("\n"," ")
                file_list=[]
                file_list=file_string.split()
                rd_flg=1
# Handle the error scenarios for failed command-line executions
        else:
                print("\n[Message]:Can not read the list of files in this folder\n")
      
        return file_list

def main():
	os.chdir("/home/satish/download/training_set")       
	file_list=Get_ListofFiles()
	for file in file_list:
		f = open(file,"r")
		lines = f.readlines()
		f.close()
		f = open(file,"w")
		for line in lines:
			if line.find(":")==-1:
				f.write(line)
		f.close()
	All=graphlab.SFrame()
	for file in file_list:
		data=graphlab.SFrame.read_csv(file,delimiter=',',header=False,error_bad_lines=False,column_type_hints=[int,int,str])	
		n=file.strip('mtvx_.')
		arr=[]
		arr.append(int(n))
		arr1=arr*data.num_rows()
		sa=graphlab.SArray(arr1)
		data.add_column(sa,name='movie')
		data.rename({'X1':'User','X2':'Rating','X3':'Date','movie':'Movie'})
		All=All.append(data)
	All.save('netflix_training_sframe')	

main()

	





